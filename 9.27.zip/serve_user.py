from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_cors import CORS
import json

app = Flask(__name__)
CORS(app)  # 启用CORS
app.secret_key = 'zfy_so_handsome'  # 密钥


# 定义save_user_pass存储用户名密码
def save_user_pass(username, password, filename='user_pass.json'):
    # 读取现有的用户数据（如果文件不存在，则为空字典）
    print(password, username)
    try:
        with open(filename, 'r') as f:  # with自动关闭
            user_pass = json.load(f)
    except FileNotFoundError:
        user_pass = {}  # 原有json打开为字典
    if username in user_pass:
        return False
    user_pass[username] = password  # 更新字典
    with open(filename, 'w') as f:
        json.dump(user_pass, f, indent=4)  # 将更新后的字典写回文件，使用indent=4来增加可读性
    return True


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        filename = 'user_pass.json'
        try:
            with open(filename, 'r') as f:
                user_pass = json.load(f)
        except FileNotFoundError:
            user_pass = {}  # 打开字典

        if username in user_pass and user_pass[username] == password:
            session['username'] = username  # 登录成功，将用户名cun到session中
            return redirect(url_for('index'))
        else:
            return '账号和密码错误'
    return render_template('login.html')  # get请求就返回login.html


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if save_user_pass(username, password):  #保存user_pass
            data={
            "username": username,
            "power": 0,
            "knowledge": 0,
            "resource_number": [
             0,
              0,
                 0
             ],
            "machine_number": [
        [
            0,
            0
        ],
        [
            0,
            0
        ],
        [
            0,
            0
        ]
    ],
    "machine_study_number": [
        0,
        0
    ],
    "machine_power_number": [
        0,
        0
    ],
    "unlock_switch":[1,0,0,0,0,0,0],
    "machine_switch":[[1,1],[1,1],[1,1]],
    "machine_power_switch":[1,1]
}
            with open(f'user_data/{username}.json', 'w') as file:
                json.dump(data, file, indent=4)
            return redirect(url_for('login'))  # 注册成功
        else:
            return '账号已存在'
    return render_template('register.html')  # get请求就返回register.html


@app.route('/')
def index():
    if 'username' in session:
        return render_template('index.html', username=session.get('username'))
    return '请登录或注册 <a href="/login">登录</a> <a href="/register">注册</a>'


@app.route('/logout')
def logout():
    session.pop('username', None)  # 登出，删除session中的username
    return redirect(url_for('index'))


@app.route('/save', methods=['POST'])
def save():
    data = request.json  # 从请求中获取JSON数据
    username=data.get('username')
    with open(f'user_data/{username}.json', 'w') as file:
        json.dump(data, file, indent=4)
    print(data)  # 打印接收到的数据
    return jsonify({'status': 'success', 'message': 'Data received successfully'})


if __name__ == '__main__':
    app.run()
